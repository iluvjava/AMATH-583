#!/bin/bash
 
bash verify-make.bash
bash verify-test.bash
bash verify-run.bash
