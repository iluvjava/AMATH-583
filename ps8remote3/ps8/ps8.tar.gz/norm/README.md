

The script strong_script.bash will run two sets of benchmarks.  The benchmark runs mpi_norm.exe from 1 to 32 processors (in powers of two) and records the time.  The first set of benchmarks does this for just one trip while the second does it for two trips.  Results are saved in strong-time-{1,10}.pdf.


Each benchmark run will take 1-2 minutes.

