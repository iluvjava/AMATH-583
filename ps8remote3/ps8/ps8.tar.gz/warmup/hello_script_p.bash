#!/bin/bash

echo "Hello from Slurm!"
srun hostname
echo "Goodbye"
