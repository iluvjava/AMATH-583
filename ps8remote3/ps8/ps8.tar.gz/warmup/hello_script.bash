#!/bin/bash

echo "Hello from Slurm!"
hostname
echo "Goodbye"
