#!/bin/bash

echo "Hello from Slurm!"
mpirun hostname
echo "Goodbye"
