#!/bin/bash

mpirun ./hello.exe
